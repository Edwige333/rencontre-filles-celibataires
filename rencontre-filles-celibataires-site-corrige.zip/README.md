# Rencontre des Filles Célibataires

Site statique prêt pour GitHub Pages.

- `index.html` : accueil
- `inscription/index.html` : inscription séparée
- `confidentialite/index.html` : confidentialité
- `cgu/index.html` : conditions

Important : GitHub Pages est un hébergement statique. Le formulaire actuel enregistre les informations uniquement dans `localStorage` sur l'appareil du visiteur. Pour de vrais comptes accessibles depuis plusieurs appareils, il faudra ensuite connecter un backend/base de données ou un service de formulaire.
